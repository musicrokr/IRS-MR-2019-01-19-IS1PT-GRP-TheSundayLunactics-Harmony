export class CustomerEvaluation{
    customerID?: number;
    debtPayingAbility?: string;
    defaulter?: boolean;
    latePaymentInd?: boolean;
    liquidity?: string;
    ltv?: number;
    newCustomer?: boolean;
    operationAbility?: string;
    profitability?: string;
    purchaseFreq?: string;
    yearsActive?: number;
}
