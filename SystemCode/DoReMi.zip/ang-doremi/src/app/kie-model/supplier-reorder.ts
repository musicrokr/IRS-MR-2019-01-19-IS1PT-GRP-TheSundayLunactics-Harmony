export class SupplierReorder{    
    customerID?: number;
    debtPayingAbility?: string;
    defaulter?: boolean;
    latePaymentInd?: boolean;
    liquidity?: boolean;
    ltv?: number;
    newCustomer?: boolean;
    operationAbility?: string;
    profitability?: string;
    purchaseFreq?: string;
    yearsActive?: number;


}
