create database jbpm;
create user jbpm with password 'jbpm';
grant all privileges on database jbpm to jbpm;
  
